def cria_coordenada(l, c):
    return (0,0)

def cria_tabuleiro():
    return None

def tabuleiro_posicao(t, c):
    return 0

def tabuleiro_preenche_posicao(t, c, v):
    return t

def tabuleiro_reduz(t, direcao):
    return t
    
def tabuleiro_terminado(t):
    return False

def tabuleiros_iguais(t1, t2):
    return False

def copia_tabuleiro(t):
    return t

def preenche_posicao_aleatoria(t):
    return t
    
def tabuleiro_pontuacao(t):
    return 0

def tabuleiro_actualiza_pontuacao(t, pont):
    return None
